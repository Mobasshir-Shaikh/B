marks <- c(45,50,55,60,62,65,68,70,72,
           75,78,80,82,85,88,90,92,95)

hist(marks,
     main = "Distribution of Marks",
     xlab = "Marks",
     ylab = "Frequency")
