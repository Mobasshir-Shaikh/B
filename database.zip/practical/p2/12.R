x <- c(1,2,3,4,5)
y <- c(10,20,30,40,50)

plot(x,y,
     main = "My Graph",
     xlab = "X Values",
     ylab = "Y Values")
