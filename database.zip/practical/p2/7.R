marks <- matrix(c(70,65,80,
                  75,70,85,
                  80,75,90),
                nrow = 3,
                byrow = TRUE)

rownames(marks) <- c("Student A","Student B","Student C")
colnames(marks) <- c("Maths","Science","Computer")

barplot(marks,
        beside = FALSE,
        main = "Stacked Bar Graph",
        xlab = "Students",
        ylab = "Marks",
        legend.text = TRUE,
        col = c("red","blue","green"))
