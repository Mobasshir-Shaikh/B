
# ==========================================
# PRACTICAL 2: GRAPHS USING R
# MASTER CODE
# ==========================================


# Q1. LINE GRAPH

month <- c("Jan","Feb","Mar","Apr","May","Jun")
sales <- c(20,25,30,28,35,40)

plot(1:6, sales,
     type = "o",
     main = "Monthly Sales",
     xlab = "Month",
     ylab = "Sales",
     xaxt = "n")

axis(1, at = 1:6, labels = month)


# Q2. MULTIPLE LINE GRAPH

month <- 1:6
productA <- c(20,25,30,35,40,45)
productB <- c(15,22,28,31,37,42)

plot(month, productA,
     type = "o",
     xlab = "Month",
     ylab = "Sales",
     main = "Product Sales")

lines(month, productB, type = "o")

legend("topleft",
       legend = c("Product A","Product B"),
       lty = 1)


# Q3. SIMPLE BAR GRAPH

students <- c("A","B","C","D","E")
marks <- c(65,72,80,55,90)

barplot(marks,
        names.arg = students,
        main = "Student Marks",
        xlab = "Students",
        ylab = "Marks")


# Q4. DIVISION / GROUPED BAR GRAPH

marks <- matrix(c(70,65,80,
                  75,70,85,
                  80,75,90),
                nrow = 3,
                byrow = TRUE)

rownames(marks) <- c("Student A","Student B","Student C")
colnames(marks) <- c("Maths","Science","Computer")

barplot(marks,
        beside = TRUE,
        main = "Division Bar Graph",
        xlab = "Students",
        ylab = "Marks",
        legend.text = TRUE)


# Q5. HORIZONTAL BAR GRAPH

students <- c("A","B","C","D","E")
marks <- c(65,72,80,55,90)

barplot(marks,
        names.arg = students,
        horiz = TRUE,
        main = "Horizontal Bar Graph",
        xlab = "Marks",
        ylab = "Students")


# Q6. GROUPED BAR GRAPH

marks <- matrix(c(70,65,80,
                  75,70,85,
                  80,75,90),
                nrow = 3,
                byrow = TRUE)

rownames(marks) <- c("Student A","Student B","Student C")
colnames(marks) <- c("Maths","Science","Computer")

barplot(marks,
        beside = TRUE,
        main = "Grouped Bar Graph",
        xlab = "Students",
        ylab = "Marks",
        legend.text = TRUE,
        col = c("red","blue","green"))


# Q7. STACKED BAR GRAPH

marks <- matrix(c(70,65,80,
                  75,70,85,
                  80,75,90),
                nrow = 3,
                byrow = TRUE)

rownames(marks) <- c("Student A","Student B","Student C")
colnames(marks) <- c("Maths","Science","Computer")

barplot(marks,
        beside = FALSE,
        main = "Stacked Bar Graph",
        xlab = "Students",
        ylab = "Marks",
        legend.text = TRUE,
        col = c("red","blue","green"))


# Q8. PIE CHART

expenses <- c(3000,2000,1500,1000,2500)

categories <- c("Food","Travel","Education",
                "Medical","Other")

pie(expenses,
    labels = categories,
    main = "Monthly Expenses")


# Q9. HISTOGRAM

marks <- c(45,50,55,60,62,65,68,70,72,
           75,78,80,82,85,88,90,92,95)

hist(marks,
     main = "Distribution of Marks",
     xlab = "Marks",
     ylab = "Frequency")


# Q10. SCATTER PLOT

study_hours <- c(2,3,4,5,6,7,8)
marks <- c(45,50,55,60,68,75,85)

plot(study_hours, marks,
     main = "Study Hours vs Marks",
     xlab = "Study Hours",
     ylab = "Marks",
     pch = 19)


# Q11. BOX PLOT

marks <- c(45,50,55,60,65,68,70,72,75,80,85,90)

boxplot(marks,
        main = "Box Plot of Marks",
        ylab = "Marks")


# Q12. ADD TITLES AND LABELS

x <- c(1,2,3,4,5)
y <- c(10,20,30,40,50)

plot(x,y,
     main = "My Graph",
     xlab = "X Values",
     ylab = "Y Values")


# Q13. ADD LEGENDS

x <- 1:5
y1 <- c(10,20,30,40,50)
y2 <- c(15,25,35,45,55)

plot(x,y1,
     type = "o",
     ylim = c(0,60),
     main = "Two Lines")

lines(x,y2,type = "o")

legend("topleft",
       legend = c("Line 1","Line 2"),
       lty = 1)


# Q14. CUSTOMIZE SYMBOLS, COLOURS AND LINE TYPES

x <- 1:5
y <- c(10,20,30,40,50)

plot(x,y,
     type = "o",
     col = "red",
     pch = 19,
     lty = 2,
     lwd = 2,
     main = "Customized Graph",
     xlab = "X Values",
     ylab = "Y Values")


# Q15. REGRESSION LINE ON SCATTER PLOT

study_hours <- c(2,3,4,5,6,7,8)
marks <- c(45,50,55,60,68,75,85)

plot(study_hours, marks,
     main = "Regression Line",
     xlab = "Study Hours",
     ylab = "Marks",
     pch = 19)

model <- lm(marks ~ study_hours)

abline(model, col = "red")


# Q16. GRAPH USING GGPLOT2
# Additional code: PDF mein detailed code nahi diya gaya.

# install.packages("ggplot2")
library(ggplot2)

data <- data.frame(
  students = c("A","B","C","D","E"),
  marks = c(65,72,80,55,90)
)

ggplot(data, aes(x = students, y = marks)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "Student Marks",
       x = "Students",
       y = "Marks")


# ==========================================
# END OF PRACTICAL 2
# ==========================================
