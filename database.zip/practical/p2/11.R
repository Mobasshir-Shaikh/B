marks <- c(45,50,55,60,65,68,70,72,75,80,85,90)

boxplot(marks,
        main = "Box Plot of Marks",
        ylab = "Marks")
