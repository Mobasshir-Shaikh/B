month <- c("Jan","Feb","Mar","Apr","May","Jun")
sales <- c(20,25,30,28,35,40)

plot(1:6, sales,
     type = "o",
     main = "Monthly Sales",
     xlab = "Month",
     ylab = "Sales",
     xaxt = "n")

axis(1, at = 1:6, labels = month)
