month <- 1:6
productA <- c(20,25,30,35,40,45)
productB <- c(15,22,28,31,37,42)

plot(month, productA,
     type = "o",
     xlab = "Month",
     ylab = "Sales",
     main = "Product Sales")

lines(month, productB, type = "o")

legend("topleft",
       legend = c("Product A","Product B"),
       lty = 1)
