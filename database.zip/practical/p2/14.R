x <- 1:5
y <- c(10,20,30,40,50)

plot(x,y,
     type = "o",
     col = "red",
     pch = 19,
     lty = 2,
     main = "Customized Graph",
     xlab = "X Values",
     ylab = "Y Values")
