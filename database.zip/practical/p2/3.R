students <- c("A","B","C","D","E")
marks <- c(65,72,80,55,90)

barplot(marks,
        names.arg = students,
        main = "Student Marks",
        xlab = "Students",
        ylab = "Marks")
