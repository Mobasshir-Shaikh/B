expenses <- c(3000,2000,1500,1000,2500)

categories <- c("Food","Travel","Education",
                "Medical","Other")

pie(expenses,
    labels = categories,
    main = "Monthly Expenses")
