x <- 1:5
y1 <- c(10,20,30,40,50)
y2 <- c(15,25,35,45,55)

plot(x,y1,
     type = "o",
     ylim = c(0,60),
     main = "Two Lines")

lines(x,y2,type = "o")

legend("topleft",
       legend = c("Line 1","Line 2"),
       lty = 1)
