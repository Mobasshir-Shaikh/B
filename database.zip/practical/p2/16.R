install.packages("ggplot2")

library(ggplot2)

data <- data.frame(
  students = c("A","B","C","D","E"),
  marks = c(65,72,80,55,90)
)

ggplot(data, aes(x = students, y = marks)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "Student Marks",
       x = "Students",
       y = "Marks")
