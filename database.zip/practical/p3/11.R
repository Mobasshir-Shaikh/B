library(ggplot2)
library(tidyr)

data <- data.frame(
  Month = factor(
    c("Jan", "Feb", "Mar", "Apr", "May", "Jun"),
    levels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun")
  ),
  Product_A = c(20, 25, 30, 35, 40, 45),
  Product_B = c(15, 22, 28, 30, 38, 42)
)

data_long <- pivot_longer(
  data,
  cols = Product_A:Product_B,
  names_to = "Product",
  values_to = "Sales"
)

ggplot(
  data_long,
  aes(
    x = Month,
    y = Sales,
    group = Product,
    linetype = Product
  )
) +
  geom_line() +
  geom_point() +
  labs(
    title = "Monthly Sales of Products",
    x = "Month",
    y = "Sales",
    linetype = "Product"
  ) +
  theme_minimal()
