library(ggplot2)
library(tidyr)

data <- data.frame(
  Student = c("A", "B", "C", "D"),
  Mathematics = c(75, 80, 65, 90),
  Statistics = c(70, 85, 72, 88),
  Computer = c(80, 78, 85, 92)
)

data_long <- pivot_longer(
  data,
  cols = Mathematics:Computer,
  names_to = "Subject",
  values_to = "Marks"
)

ggplot(data_long,
       aes(x = Student, y = Marks, fill = Subject)) +
  geom_col(position = "dodge") +
  labs(
    title = "Student Marks by Subject",
    x = "Student",
    y = "Marks",
    fill = "Subject"
  ) +
  theme_minimal()
