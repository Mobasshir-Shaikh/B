library(ggplot2)
library(tidyr)

marks <- data.frame(
  Marks = c(
    35, 42, 45, 48, 50, 52, 55, 57,
    60, 62, 64, 65, 68, 70, 72, 75,
    78, 80, 82, 85, 88, 90
  )
)

ggplot(marks, aes(x = Marks)) +
  geom_histogram(
    binwidth = 10,
    boundary = 0,
    alpha = 0.5
  ) +
  geom_freqpoly(
    binwidth = 10,
    linewidth = 1
  ) +
  labs(
    title = "Histogram and Frequency Polygon",
    x = "Marks",
    y = "Frequency"
  ) +
  theme_minimal()
