library(ggplot2)
library(tidyr)

data <- data.frame(
  Course = c("CS", "IT", "DS", "AI"),
  Students = c(40, 30, 20, 10)
)

ggplot(data, aes(x = "", y = Students, fill = Course)) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  labs(
    title = "Students by Course",
    fill = "Course"
  ) +
  theme_void()
