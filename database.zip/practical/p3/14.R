library(ggplot2)
library(tidyr)

data <- data.frame(
  Marks = c(
    45, 50, 52, 55, 58,
    60, 62, 65, 68, 70,
    72, 75, 78, 80, 85
  )
)

ggplot(data, aes(y = Marks)) +
  geom_boxplot() +
  labs(
    title = "Box Plot of Marks",
    y = "Marks"
  ) +
  theme_minimal()
