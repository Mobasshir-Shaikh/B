install.packages("ggplot2")
install.packages("tidyr")

# ==========================================
# PRACTICAL 3: DIAGRAMS USING R
# COMPLETE MASTER CODE
# ==========================================


# 3.2 SIMPLE BAR DIAGRAM

library(ggplot2)
library(tidyr)

data <- data.frame(
  Subject = c("Mathematics", "Statistics",
              "Computer Science", "DBMS", "Python"),
  Students = c(40, 35, 50, 45, 55)
)

ggplot(data, aes(x = Subject, y = Students)) +
  geom_col() +
  labs(title = "Number of Students by Subject",
       x = "Subject",
       y = "Number of Students") +
  theme_minimal()


# 3.3 MULTIPLE / GROUPED BAR DIAGRAM

library(ggplot2)
library(tidyr)

data <- data.frame(
  Student = c("A", "B", "C", "D"),
  Mathematics = c(75, 80, 65, 90),
  Statistics = c(70, 85, 72, 88),
  Computer = c(80, 78, 85, 92)
)

data_long <- pivot_longer(
  data,
  cols = Mathematics:Computer,
  names_to = "Subject",
  values_to = "Marks"
)

ggplot(data_long, aes(x = Student, y = Marks, fill = Subject)) +
  geom_col(position = "dodge") +
  labs(title = "Student Marks by Subject",
       x = "Student",
       y = "Marks",
       fill = "Subject") +
  theme_minimal()


# 3.4 SUBDIVIDED / STACKED BAR DIAGRAM

library(ggplot2)
library(tidyr)

data <- data.frame(
  Class = c("FY", "SY", "TY"),
  Boys = c(30, 25, 35),
  Girls = c(20, 30, 25)
)

data_long <- pivot_longer(
  data,
  cols = Boys:Girls,
  names_to = "Gender",
  values_to = "Students"
)

ggplot(data_long, aes(x = Class, y = Students, fill = Gender)) +
  geom_col() +
  labs(title = "Students by Class and Gender",
       x = "Class",
       y = "Number of Students",
       fill = "Gender") +
  theme_minimal()


# 3.5 PERCENTAGE BAR DIAGRAM

library(ggplot2)
library(tidyr)

data <- data.frame(
  Class = c("FY", "SY", "TY"),
  Boys = c(30, 25, 35),
  Girls = c(20, 30, 25)
)

data_long <- pivot_longer(
  data,
  cols = Boys:Girls,
  names_to = "Gender",
  values_to = "Students"
)

ggplot(data_long, aes(x = Class, y = Students, fill = Gender)) +
  geom_col(position = "fill") +
  scale_y_continuous(
    labels = function(x) paste0(x * 100, "%")
  ) +
  labs(title = "Percentage Distribution of Students",
       x = "Class",
       y = "Percentage",
       fill = "Gender") +
  theme_minimal()


# 3.6 PIE DIAGRAM

library(ggplot2)
library(tidyr)

data <- data.frame(
  Course = c("CS", "IT", "DS", "AI"),
  Students = c(40, 30, 20, 10)
)

ggplot(data, aes(x = "", y = Students, fill = Course)) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  labs(title = "Students by Course",
       fill = "Course") +
  theme_void()


# 3.7 PIE DIAGRAM WITH VALUES

library(ggplot2)
library(tidyr)

data <- data.frame(
  Course = c("CS", "IT", "DS", "AI"),
  Students = c(40, 30, 20, 10)
)

ggplot(data, aes(x = "", y = Students, fill = Course)) +
  geom_col(width = 1) +
  geom_text(
    aes(label = Students),
    position = position_stack(vjust = 0.5)
  ) +
  coord_polar(theta = "y") +
  labs(title = "Course-wise Distribution of Students",
       fill = "Course") +
  theme_void()


# 3.8 HISTOGRAM

library(ggplot2)
library(tidyr)

marks <- data.frame(
  Marks = c(35, 42, 45, 48, 50, 52, 55, 57,
            60, 62, 64, 65, 68, 70, 72, 75,
            78, 80, 82, 85, 88, 90)
)

ggplot(marks, aes(x = Marks)) +
  geom_histogram(binwidth = 10, boundary = 0) +
  labs(title = "Distribution of Marks",
       x = "Marks",
       y = "Frequency") +
  theme_minimal()


# 3.9 FREQUENCY POLYGON

library(ggplot2)
library(tidyr)

marks <- data.frame(
  Marks = c(35, 42, 45, 48, 50, 52, 55, 57,
            60, 62, 64, 65, 68, 70, 72, 75,
            78, 80, 82, 85, 88, 90)
)

ggplot(marks, aes(x = Marks)) +
  geom_freqpoly(binwidth = 10) +
  labs(title = "Frequency Polygon of Marks",
       x = "Marks",
       y = "Frequency") +
  theme_minimal()


# 3.10 HISTOGRAM AND FREQUENCY POLYGON TOGETHER

library(ggplot2)
library(tidyr)

marks <- data.frame(
  Marks = c(35, 42, 45, 48, 50, 52, 55, 57,
            60, 62, 64, 65, 68, 70, 72, 75,
            78, 80, 82, 85, 88, 90)
)

ggplot(marks, aes(x = Marks)) +
  geom_histogram(binwidth = 10,
                 boundary = 0,
                 alpha = 0.5) +
  geom_freqpoly(binwidth = 10, linewidth = 1) +
  labs(title = "Histogram and Frequency Polygon",
       x = "Marks",
       y = "Frequency") +
  theme_minimal()


# 3.11 LINE DIAGRAM

library(ggplot2)
library(tidyr)

data <- data.frame(
  Month = factor(
    c("Jan", "Feb", "Mar", "Apr", "May", "Jun"),
    levels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun")
  ),
  Sales = c(20, 25, 30, 28, 35, 40)
)

ggplot(data, aes(x = Month, y = Sales, group = 1)) +
  geom_line() +
  geom_point() +
  labs(title = "Monthly Sales",
       x = "Month",
       y = "Sales") +
  theme_minimal()


# 3.12 MULTIPLE LINE DIAGRAM

library(ggplot2)
library(tidyr)

data <- data.frame(
  Month = factor(
    c("Jan", "Feb", "Mar", "Apr", "May", "Jun"),
    levels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun")
  ),
  Product_A = c(20, 25, 30, 35, 40, 45),
  Product_B = c(15, 22, 28, 30, 38, 42)
)

data_long <- pivot_longer(
  data,
  cols = Product_A:Product_B,
  names_to = "Product",
  values_to = "Sales"
)

ggplot(data_long,
       aes(x = Month, y = Sales,
           group = Product, linetype = Product)) +
  geom_line() +
  geom_point() +
  labs(title = "Monthly Sales of Products",
       x = "Month",
       y = "Sales",
       linetype = "Product") +
  theme_minimal()


# 3.13 SCATTER PLOT

library(ggplot2)
library(tidyr)

data <- data.frame(
  Hours = c(1, 2, 3, 4, 5, 6, 7, 8),
  Marks = c(40, 45, 50, 55, 60, 68, 72, 80)
)

ggplot(data, aes(x = Hours, y = Marks)) +
  geom_point() +
  labs(title = "Study Hours vs Marks",
       x = "Study Hours",
       y = "Marks") +
  theme_minimal()


# 3.14 SCATTER PLOT WITH REGRESSION LINE

library(ggplot2)
library(tidyr)

data <- data.frame(
  Hours = c(1, 2, 3, 4, 5, 6, 7, 8),
  Marks = c(40, 45, 50, 55, 60, 68, 72, 80)
)

ggplot(data, aes(x = Hours, y = Marks)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Study Hours vs Marks",
       x = "Study Hours",
       y = "Marks") +
  theme_minimal()


# 3.15 BOX PLOT

library(ggplot2)
library(tidyr)

data <- data.frame(
  Marks = c(45, 50, 52, 55, 58,
            60, 62, 65, 68, 70,
            72, 75, 78, 80, 85)
)

ggplot(data, aes(y = Marks)) +
  geom_boxplot() +
  labs(title = "Box Plot of Marks",
       y = "Marks") +
  theme_minimal()


# 3.16 MULTIPLE BOX PLOT

library(ggplot2)
library(tidyr)

data <- data.frame(
  Subject = rep(c("Mathematics", "Statistics", "Computer"),
                each = 8),
  Marks = c(
    55, 60, 62, 65, 68, 70, 72, 75,
    50, 55, 58, 60, 64, 66, 70, 72,
    60, 65, 68, 70, 73, 75, 78, 82
  )
)

ggplot(data, aes(x = Subject, y = Marks)) +
  geom_boxplot() +
  labs(title = "Subject-wise Distribution of Marks",
       x = "Subject",
       y = "Marks") +
  theme_minimal()


# 3.17 CUSTOMIZING DIAGRAMS

library(ggplot2)
library(tidyr)

data <- data.frame(
  Subject = rep(c("Mathematics", "Statistics", "Computer"),
                each = 8),
  Marks = c(
    55, 60, 62, 65, 68, 70, 72, 75,
    50, 55, 58, 60, 64, 66, 70, 72,
    60, 65, 68, 70, 73, 75, 78, 82
  )
)

ggplot(data, aes(x = Subject, y = Marks)) +
  geom_boxplot() +
  labs(title = "Subject-wise Marks",
       x = "Subject",
       y = "Marks") +
  theme_minimal()


# ==========================================
# END OF PRACTICAL 3 MASTER CODE
# ==========================================
