library(ggplot2)
library(tidyr)

data <- data.frame(
  Course = c("CS", "IT", "DS", "AI"),
  Students = c(40, 30, 20, 10)
)

ggplot(data, aes(x = "", y = Students, fill = Course)) +
  geom_col(width = 1) +
  geom_text(
    aes(label = Students),
    position = position_stack(vjust = 0.5)
  ) +
  coord_polar(theta = "y") +
  labs(
    title = "Course-wise Distribution of Students",
    fill = "Course"
  ) +
  theme_void()
