library(ggplot2)
library(tidyr)

data <- data.frame(
  Month = factor(
    c("Jan", "Feb", "Mar", "Apr", "May", "Jun"),
    levels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun")
  ),
  Sales = c(20, 25, 30, 28, 35, 40)
)

ggplot(data, aes(x = Month, y = Sales, group = 1)) +
  geom_line() +
  geom_point() +
  labs(
    title = "Monthly Sales",
    x = "Month",
    y = "Sales"
  ) +
  theme_minimal()
