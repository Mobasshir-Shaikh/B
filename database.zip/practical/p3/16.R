library(ggplot2)
library(tidyr)

data <- data.frame(
  Subject = rep(
    c("Mathematics", "Statistics", "Computer"),
    each = 8
  ),
  Marks = c(
    55, 60, 62, 65, 68, 70, 72, 75,
    50, 55, 58, 60, 64, 66, 70, 72,
    60, 65, 68, 70, 73, 75, 78, 82
  )
)

ggplot(data, aes(x = Subject, y = Marks)) +
  geom_boxplot() +
  labs(
    title = "Subject-wise Distribution of Marks",
    x = "Subject",
    y = "Marks"
  ) +
  theme_minimal()
