library(ggplot2)
library(tidyr)

data <- data.frame(
  Hours = c(1, 2, 3, 4, 5, 6, 7, 8),
  Marks = c(40, 45, 50, 55, 60, 68, 72, 80)
)

ggplot(data, aes(x = Hours, y = Marks)) +
  geom_point() +
  geom_smooth(
    method = "lm",
    se = FALSE
  ) +
  labs(
    title = "Study Hours vs Marks",
    x = "Study Hours",
    y = "Marks"
  ) +
  theme_minimal()
