library(ggplot2)
library(tidyr)

data <- data.frame(
  Class = c("FY", "SY", "TY"),
  Boys = c(30, 25, 35),
  Girls = c(20, 30, 25)
)

data_long <- pivot_longer(
  data,
  cols = Boys:Girls,
  names_to = "Gender",
  values_to = "Students"
)

ggplot(data_long,
       aes(x = Class, y = Students, fill = Gender)) +
  geom_col(position = "fill") +
  scale_y_continuous(
    labels = function(x) paste0(x * 100, "%")
  ) +
  labs(
    title = "Percentage Distribution of Students",
    x = "Class",
    y = "Percentage",
    fill = "Gender"
  ) +
  theme_minimal()
