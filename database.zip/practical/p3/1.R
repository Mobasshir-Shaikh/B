library(ggplot2)
library(tidyr)

data <- data.frame(
  Subject = c("Mathematics", "Statistics",
              "Computer Science", "DBMS", "Python"),
  Students = c(40, 35, 50, 45, 55)
)

ggplot(data, aes(x = Subject, y = Students)) +
  geom_col() +
  labs(
    title = "Number of Students by Subject",
    x = "Subject",
    y = "Number of Students"
  ) +
  theme_minimal()
