library(stats)

# Create data
Advertising <- c(10,20,30,40,50,60,70,80)
Sales <- c(25,32,40,45,52,60,65,72)

# Create data frame
data <- data.frame(Advertising, Sales)

# Fit regression model
model <- lm(Sales ~ Advertising, data = data)

# Display summary
summary(model)

# Regression coefficients
coef(model)

# R-squared
summary(model)$r.squared

# Test significance
anova(model)

# Predict sales for advertising = 90
newdata <- data.frame(Advertising = 90)
predict(model, newdata)

# Plot graph
plot(Advertising, Sales,
     main = "Advertising vs Sales",
     xlab = "Advertising",
     ylab = "Sales",
     pch = 19)

# Add regression line
abline(model, lwd = 2)
