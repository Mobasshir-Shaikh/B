library(stats)

# Create data
hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

# Create data frame
data <- data.frame(hours, marks)

# Display data
print(data)

# Fit regression model
model <- lm(marks ~ hours, data = data)

# Display model summary
summary(model)

# Display coefficients
coef(model)

# Predict marks for 12 hours
newdata <- data.frame(hours = 12)
prediction <- predict(model, newdata)

print(prediction)

# Plot data
plot(hours, marks,
     main = "Simple Linear Regression",
     xlab = "Hours Studied",
     ylab = "Marks",
     pch = 19)

# Add regression line
abline(model, lwd = 2)
