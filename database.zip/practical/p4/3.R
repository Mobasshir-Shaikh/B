library(stats)

# Create data
Temperature <- c(20,22,24,26,28,30,32,34)

IceCreamSales <- c(100,110,125,140,150,165,180,200)

# Create data frame
data <- data.frame(Temperature, IceCreamSales)

# Fit regression model
model <- lm(IceCreamSales ~ Temperature, data = data)

# Display summary
summary(model)

# Regression coefficients
coef(model)

# R-squared
summary(model)$r.squared

# Predict sales at 35 degree
newdata <- data.frame(Temperature = 35)

prediction <- predict(model, newdata)

print(prediction)

# Plot graph
plot(Temperature, IceCreamSales,
     main = "Temperature vs Ice Cream Sales",
     xlab = "Temperature",
     ylab = "Ice Cream Sales",
     pch = 19)

# Add regression line
abline(model, lwd = 2)
