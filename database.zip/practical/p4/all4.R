
# ==========================================
# PRACTICAL 4
# SIMPLE LINEAR REGRESSION USING R
# COMPLETE MASTER CODE
# ==========================================


# Q1. SIMPLE LINEAR REGRESSION

library(stats)

# Create data
hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

# Create data frame
data <- data.frame(hours, marks)

# Display data
print(data)

# Fit regression model
model <- lm(marks ~ hours, data = data)

# Display model summary
summary(model)

# Display coefficients
coef(model)

# Predict marks for 12 hours
newdata <- data.frame(hours = 12)
prediction <- predict(model, newdata)

print(prediction)

# Plot data
plot(hours, marks,
     main = "Simple Linear Regression",
     xlab = "Hours Studied",
     ylab = "Marks",
     pch = 19)

# Add regression line
abline(model, lwd = 2)


# Q2. FITTED VALUES

library(stats)

hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

data <- data.frame(hours, marks)
model <- lm(marks ~ hours, data = data)

fitted(model)


# Q3. RESIDUALS

library(stats)

hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

data <- data.frame(hours, marks)
model <- lm(marks ~ hours, data = data)

residuals(model)


# Q4. R-SQUARED AND ADJUSTED R-SQUARED

library(stats)

hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

data <- data.frame(hours, marks)
model <- lm(marks ~ hours, data = data)

summary(model)$r.squared
summary(model)$adj.r.squared


# Q5. CONFIDENCE INTERVALS

library(stats)

hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

data <- data.frame(hours, marks)
model <- lm(marks ~ hours, data = data)

confint(model)


# Q6. ANOVA

library(stats)

hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

data <- data.frame(hours, marks)
model <- lm(marks ~ hours, data = data)

anova(model)


# Q7. PREDICTION WITH CONFIDENCE INTERVAL

library(stats)

hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

data <- data.frame(hours, marks)
model <- lm(marks ~ hours, data = data)

newdata <- data.frame(hours = 12)

predict(model, newdata, interval = "confidence")


# Q8. PREDICTION WITH PREDICTION INTERVAL

library(stats)

hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

data <- data.frame(hours, marks)
model <- lm(marks ~ hours, data = data)

newdata <- data.frame(hours = 12)

predict(model, newdata, interval = "prediction")


# Q9. CORRELATION

library(stats)

hours <- c(2,3,4,5,6,7,8,9,10,11)
marks <- c(45,50,55,60,65,70,75,80,85,90)

cor(hours, marks)


# Q10. PRACTICE QUESTION 1
# ADVERTISING AND SALES

library(stats)

# Create data
Advertising <- c(10,20,30,40,50,60,70,80)
Sales <- c(25,32,40,45,52,60,65,72)

# Create data frame
data <- data.frame(Advertising, Sales)

# Fit regression model
model <- lm(Sales ~ Advertising, data = data)

# Display data
print(data)

# Model summary
summary(model)

# Regression coefficients
coef(model)

# R-squared
summary(model)$r.squared

# Test significance using ANOVA
anova(model)

# Predict sales when advertising = 90
newdata <- data.frame(Advertising = 90)
prediction <- predict(model, newdata)

print(prediction)

# Plot graph
plot(Advertising, Sales,
     main = "Advertising vs Sales",
     xlab = "Advertising",
     ylab = "Sales",
     pch = 19)

# Add regression line
abline(model, lwd = 2)


# Q11. PRACTICE QUESTION 2
# TEMPERATURE AND ICE CREAM SALES

library(stats)

# Create data
Temperature <- c(20,22,24,26,28,30,32,34)

IceCreamSales <- c(100,110,125,140,150,165,180,200)

# Create data frame
data <- data.frame(Temperature, IceCreamSales)

# Fit regression model
model <- lm(IceCreamSales ~ Temperature, data = data)

# Display data
print(data)

# Model summary
summary(model)

# Regression coefficients
coef(model)

# R-squared
summary(model)$r.squared

# Predict sales at 35 degree
newdata <- data.frame(Temperature = 35)

prediction <- predict(model, newdata)

print(prediction)

# Plot graph
plot(Temperature, IceCreamSales,
     main = "Temperature vs Ice Cream Sales",
     xlab = "Temperature",
     ylab = "Ice Cream Sales",
     pch = 19)

# Add regression line
abline(model, lwd = 2)


# ==========================================
# END OF PRACTICAL 4 MASTER CODE
# ==========================================
