# Practical 4

marks <- c(45, 56, 67, 78, 89, 72, 81)

marks
marks[1]
marks[3]
marks[length(marks)]
