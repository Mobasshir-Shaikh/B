# Practical 7

A <- matrix(1:9, nrow = 3, ncol = 3)
B <- matrix(9:1, nrow = 3, ncol = 3)

# Display matrices
A
B

# Matrix addition
A + B

# Transpose
t(A)

# Row sums
rowSums(A)

# Column sums
colSums(A)
