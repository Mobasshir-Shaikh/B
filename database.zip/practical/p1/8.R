# Practical 9

gender <- factor(
  c("Male", "Female", "Male", "Female",
    "Female", "Male", "Female", "Female")
)

# Display factor values
gender

# Display levels
levels(gender)

# Frequency table
table(gender)
