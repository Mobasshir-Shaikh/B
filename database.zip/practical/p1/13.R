# Practical 14

student <- data.frame(
  RollNo = 1:10,
  Name = c("Amit", "Riya", "Rahul", "Neha", "Pooja",
           "Karan", "Sneha", "Rohan", "Anita", "Vikas"),
  Marks = c(78, 85, 67, 90, 72, 81, 88, 69, 95, 76)
)

# First six records
head(student)

# Last six records
tail(student)

# First five records
head(student, 5)

# Last five records
tail(student, 5)

# First three records
head(student, 3)

# Last three records
tail(student, 3)
