# Practical 11

# Five repetitions of 10
rep(10, times = 5)

# Repeat vector three times
rep(c(1, 2, 3), times = 3)

# Repeat each number three times
rep(c(1, 2, 3), each = 3)
