# Practical 2

length <- 25
breadth <- 10

area <- length * breadth
perimeter <- 2 * (length + breadth)

area
perimeter
