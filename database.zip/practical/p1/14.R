# Practical 15

student <- data.frame(
  RollNo = 1:10,

  Name = c("Amit", "Riya", "Rahul", "Neha", "Pooja",
           "Karan", "Sneha", "Rohan", "Anita", "Vikas"),

  Gender = factor(
    c("Male", "Female", "Male", "Female", "Female",
      "Male", "Female", "Male", "Female", "Male")
  ),

  Marks = c(78, 85, 67, 90, 72, 81, 88, 69, 95, 76)
)

# Display data
student

# Structure
str(student)

# First six records
head(student)

# Last six records
tail(student)

# Summary
summary(student)

# Statistical analysis
mean(student$Marks)
median(student$Marks)
max(student$Marks)
min(student$Marks)
range(student$Marks)
sd(student$Marks)

# Sort marks
sort(student$Marks)

# Descending order
sort(student$Marks, decreasing = TRUE)

# Gender frequency
table(student$Gender)
