# Practical 13

student <- data.frame(
  RollNo = 1:5,
  Name = c("Amit", "Riya", "Rahul", "Neha", "Pooja"),
  Gender = c("Male", "Female", "Male", "Female", "Female"),
  Marks = c(78, 85, 67, 90, 72)
)

str(student)
