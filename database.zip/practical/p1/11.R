# Practical 12

marks <- c(
  45, 56, 67, 78, 89,
  72, 81, 90, 65, 74,
  60, 55, 88, 92, 70
)

summary(marks)
