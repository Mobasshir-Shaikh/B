# Practical 5

x <- c(12, 15, 18, 20, 22,
       25, 28, 30, 35, 40)

length(x)
sum(x)
mean(x)
median(x)
min(x)
max(x)
range(x)
var(x)
sd(x)
