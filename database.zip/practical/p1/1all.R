
# ==========================================
# R PROGRAMMING PRACTICAL - MASTER CODE
# ==========================================


# PRACTICAL 1: BASIC ARITHMETIC OPERATIONS

a <- 20
b <- 5

a + b
a - b
a * b
a / b
a ^ b
a %% b
a %/% b


# PRACTICAL 2: VARIABLES AND ASSIGNMENT

length <- 25
breadth <- 10

area <- length * breadth
perimeter <- 2 * (length + breadth)

area
perimeter


# PRACTICAL 3: MATHEMATICAL FUNCTIONS

x <- 50

sqrt(x)
log(x)
log10(x)
abs(x)
exp(2)


# PRACTICAL 4: CREATING AND ACCESSING A VECTOR

marks <- c(45, 56, 67, 78, 89, 72, 81)

marks
marks[1]
marks[3]
marks[length(marks)]


# PRACTICAL 5: STATISTICAL FUNCTIONS ON A VECTOR

x <- c(12, 15, 18, 20, 22, 25, 28, 30, 35, 40)

length(x)
sum(x)
mean(x)
median(x)
min(x)
max(x)
range(x)
var(x)
sd(x)


# PRACTICAL 6: SORTING A VECTOR

x <- c(45, 12, 78, 23, 56, 9, 34, 67, 21, 50)

x
sort(x)
sort(x, decreasing = TRUE)


# PRACTICAL 7: MATRIX IN R

A <- matrix(1:9, nrow = 3, ncol = 3)
B <- matrix(9:1, nrow = 3, ncol = 3)

A
B
A + B
t(A)
rowSums(A)
colSums(A)


# PRACTICAL 8: DATA FRAME

student <- data.frame(
  RollNo = 1:10,
  Name = c("Amit", "Riya", "Rahul", "Neha", "Pooja",
           "Karan", "Sneha", "Rohan", "Anita", "Vikas"),
  Gender = c("Male", "Female", "Male", "Female", "Female",
             "Male", "Female", "Male", "Female", "Male"),
  Marks = c(78, 85, 67, 90, 72, 81, 88, 69, 95, 76)
)

student
student$Name
student$Marks
student[1, ]
student[1:5, ]


# PRACTICAL 9: FACTORS

gender <- factor(c("Male", "Female", "Male", "Female",
                   "Female", "Male", "Female", "Female"))

gender
levels(gender)
table(gender)


# PRACTICAL 10: SEQUENCE GENERATION

1:50
seq(1, 25, by = 2)
seq(5, 50, by = 5)
seq(100, 10, by = -10)


# PRACTICAL 11: REPETITION IN R

rep(10, times = 5)
rep(c(1, 2, 3), times = 3)
rep(c(1, 2, 3), each = 3)


# PRACTICAL 12: SUMMARY FUNCTION

marks <- c(45, 56, 67, 78, 89, 72, 81, 90,
           65, 74, 60, 55, 88, 92, 70)

summary(marks)


# PRACTICAL 13: STRUCTURE OF DATA USING str()

student <- data.frame(
  RollNo = 1:5,
  Name = c("Amit", "Riya", "Rahul", "Neha", "Pooja"),
  Gender = c("Male", "Female", "Male", "Female", "Female"),
  Marks = c(78, 85, 67, 90, 72)
)

str(student)


# PRACTICAL 14: DISPLAY FIRST AND LAST RECORDS

student <- data.frame(
  RollNo = 1:10,
  Name = c("Amit", "Riya", "Rahul", "Neha", "Pooja",
           "Karan", "Sneha", "Rohan", "Anita", "Vikas"),
  Marks = c(78, 85, 67, 90, 72, 81, 88, 69, 95, 76)
)

head(student)
tail(student)
head(student, 5)
tail(student, 5)
head(student, 3)
tail(student, 3)


# PRACTICAL 15: COMPLETE STUDENT DATA ANALYSIS

student <- data.frame(
  RollNo = 1:10,
  Name = c("Amit", "Riya", "Rahul", "Neha", "Pooja",
           "Karan", "Sneha", "Rohan", "Anita", "Vikas"),
  Gender = factor(c("Male", "Female", "Male", "Female", "Female",
                    "Male", "Female", "Male", "Female", "Male")),
  Marks = c(78, 85, 67, 90, 72, 81, 88, 69, 95, 76)
)

student

str(student)
head(student)
tail(student)
summary(student)

mean(student$Marks)
median(student$Marks)
max(student$Marks)
min(student$Marks)
range(student$Marks)
sd(student$Marks)

sort(student$Marks)
sort(student$Marks, decreasing = TRUE)

table(student$Gender)

# ==========================================
# END OF ALL 15 PRACTICALS
# ==========================================
