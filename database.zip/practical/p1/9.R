# Practical 10

# Numbers from 1 to 50
1:50

# Odd numbers from 1 to 25
seq(1, 25, by = 2)

# Multiples of 5
seq(5, 50, by = 5)

# Decreasing sequence
seq(100, 10, by = -10)
