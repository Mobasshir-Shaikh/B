# Practical 6

x <- c(45, 12, 78, 23, 56,
       9, 34, 67, 21, 50)

# Original vector
x

# Ascending order
sort(x)

# Descending order
sort(x, decreasing = TRUE)
