# Practical 3

x <- 50

sqrt(x)
log(x)
log10(x)
abs(-x)
exp(2)
