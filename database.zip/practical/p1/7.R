# Practical 8

student <- data.frame(
  RollNo = 1:10,
  Name = c("Amit", "Riya", "Rahul", "Neha", "Pooja",
           "Karan", "Sneha", "Rohan", "Anita", "Vikas"),
  Gender = c("Male", "Female", "Male", "Female", "Female",
             "Male", "Female", "Male", "Female", "Male"),
  Marks = c(78, 85, 67, 90, 72, 81, 88, 69, 95, 76)
)

# Display complete data
student

# Access columns
student$Name
student$Marks

# Access rows
student[1,]
student[1:5,]
