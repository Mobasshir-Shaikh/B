experience<-c(1,2,3,4,5,6,7,8,9,10)
education<-c(12,13,14,15,16,17,18,18,19,20)
age<-c(23,25,27,29,31,33,35,37,39,41)
salary<-c(22000,26000,30000,35000,40000,45000,50000,55000,60000,65000)

data<-data.frame(experience,education,age,salary)
print(data)

model<-lm(salary~experience+education+age,data=data)

summary(model)
coef(model)
confint(model)
anova(model)

new_employee<-data.frame(experience=6,education=17,age=34)
prediction<-predict(model,new_employee)
print(prediction)

summary(model)$r.squared
summary(model)$adj.r.squared

library(car)
alias(model)

tryCatch(vif(model),error=function(e){message("VIF cannot be calculated: ",e$message)})

model_vif<-lm(salary~experience+education,data=data)
vif(model_vif)

graphics.off()
plot(model,which=5)
