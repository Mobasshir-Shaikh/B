
# PRACTICE 1: HOUSE PRICE PREDICTION

library(stats)

# Step 1: Create Dataset

area <- c(1000,1200,1400,1600,1800,2000,2200,2400)

bedrooms <- c(2,2,3,3,3,4,4,5)

age <- c(10,8,7,6,5,4,3,2)

price <- c(50,60,72,80,90,105,120,135)

data <- data.frame(area, bedrooms, age, price)

print(data)


# Step 2: Multiple Linear Regression

model <- lm(price ~ area + bedrooms + age,
            data = data)


# Step 3: Model Summary

summary(model)


# Step 4: Regression Equation Coefficients

coef(model)


# Step 5: R-squared

summary(model)$r.squared


# Step 6: Adjusted R-squared

summary(model)$adj.r.squared


# Step 7: Significant Predictors

summary(model)$coefficients


# Step 8: Predict House Price

new_house <- data.frame(
  area = 1500,
  bedrooms = 3,
  age = 5
)

prediction <- predict(model, newdata = new_house)

print("Predicted House Price")
print(prediction)


# Step 9: Diagnostic Plots

graphics.off()

par(mfrow = c(2,2))

plot(model)

par(mfrow = c(1,1))


# END OF PRACTICE 1
