
# PRACTICE 2: RIDGE REGRESSION

# Install package if required

if (!requireNamespace("glmnet", quietly = TRUE)) {
  install.packages("glmnet")
}

library(glmnet)


# Step 1: Create Dataset

area <- c(1000,1200,1400,1600,1800,2000,2200,2400)

bedrooms <- c(2,2,3,3,3,4,4,5)

age <- c(10,8,7,6,5,4,3,2)

price <- c(50,60,72,80,90,105,120,135)

data <- data.frame(area, bedrooms, age, price)


# Step 2: Create Predictor Matrix

x <- as.matrix(data[, c("area", "bedrooms", "age")])


# Step 3: Dependent Variable

y <- data$price


# Step 4: Fit Ridge Regression

ridge_model <- glmnet(x, y, alpha = 0)

print(ridge_model)


# Step 5: Cross Validation

set.seed(123)

cv_ridge <- cv.glmnet(x, y, alpha = 0)


# Step 6: Plot Cross Validation

plot(cv_ridge)


# Step 7: Find Lambda Minimum

print("Best Lambda")

print(cv_ridge$lambda.min)


# Step 8: Ridge Coefficients

print("Ridge Coefficients")

coef(cv_ridge, s = "lambda.min")


# Step 9: Predict New House Price

new_x <- matrix(c(1500, 3, 5), nrow = 1)

colnames(new_x) <- c("area", "bedrooms", "age")

ridge_prediction <- predict(
  cv_ridge,
  newx = new_x,
  s = "lambda.min"
)

print("Ridge Prediction")

print(ridge_prediction)


# Step 10: OLS Model

ols_model <- lm(price ~ area + bedrooms + age,
                data = data)

print("OLS Coefficients")

print(coef(ols_model))


# Step 11: Compare Ridge Coefficients

print("Ridge Coefficients")

print(coef(cv_ridge, s = "lambda.min"))


# Step 12: OLS Prediction

ols_prediction <- predict(
  ols_model,
  newdata = data.frame(
    area = 1500,
    bedrooms = 3,
    age = 5
  )
)

print("OLS Prediction")

print(ols_prediction)


# END OF PRACTICE 2
