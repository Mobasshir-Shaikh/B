
# ==============================================
# PRACTICAL 6
# MULTIPLE LINEAR REGRESSION AND RIDGE REGRESSION
# ==============================================

library(stats)

# Install packages if not already installed
if (!requireNamespace("car", quietly = TRUE)) {
  install.packages("car")
}

if (!requireNamespace("glmnet", quietly = TRUE)) {
  install.packages("glmnet")
}

library(car)
library(glmnet)


# ==============================================
# PART A: MULTIPLE LINEAR REGRESSION
# ==============================================

# Step 1: Create Dataset

experience <- c(1,2,3,4,5,6,7,8,9,10)

education <- c(12,13,14,15,16,17,18,18,19,20)

age <- c(23,25,27,29,31,33,35,37,39,41)

salary <- c(22000,26000,30000,35000,40000,
            45000,50000,55000,60000,65000)

data <- data.frame(experience, education, age, salary)

print("Original Dataset")
print(data)


# Step 2: Fit Multiple Linear Regression

model <- lm(salary ~ experience + education + age,
            data = data)

print("Model Summary")
summary(model)


# Step 3: Regression Coefficients

print("Regression Coefficients")
coef(model)


# Step 4: Confidence Intervals

print("Confidence Intervals")
confint(model)


# Step 5: ANOVA

print("ANOVA Results")
anova(model)


# Step 6: R-squared

print("R-squared")
summary(model)$r.squared


# Step 7: Adjusted R-squared

print("Adjusted R-squared")
summary(model)$adj.r.squared


# Step 8: Prediction for New Employee

new_employee <- data.frame(
  experience = 6,
  education = 17,
  age = 34
)

prediction <- predict(model, newdata = new_employee)

print("Predicted Salary")
print(prediction)


# Step 9: Check Multicollinearity

print("Alias of Model")
alias(model)

print("VIF Values")

tryCatch(
  vif(model),
  error = function(e) {
    message("VIF cannot be calculated: ", e$message)
  }
)


# Step 10: VIF after removing Age

model_vif <- lm(salary ~ experience + education,
                data = data)

print("VIF after removing Age")
vif(model_vif)


# Step 11: Diagnostic Plots

graphics.off()

par(mfrow = c(2,2))
plot(model)

par(mfrow = c(1,1))


# ==============================================
# PART B: RIDGE REGRESSION
# ==============================================

# Step 1: Create Predictor Matrix

x <- as.matrix(data[, c("experience",
                        "education",
                        "age")])

# Step 2: Dependent Variable

y <- data$salary


# Step 3: Fit Ridge Regression

ridge_model <- glmnet(x, y, alpha = 0)

print("Ridge Regression Model")
print(ridge_model)


# Step 4: Cross Validation

set.seed(123)

cv_ridge <- cv.glmnet(x, y, alpha = 0)


# Step 5: Cross Validation Plot

plot(cv_ridge)


# Step 6: Best Lambda

print("Lambda Minimum")
print(cv_ridge$lambda.min)


# Step 7: Lambda 1SE

print("Lambda 1SE")
print(cv_ridge$lambda.1se)


# Step 8: Ridge Coefficients

print("Ridge Coefficients")

coef(cv_ridge, s = "lambda.min")


# Step 9: Ridge Prediction

new_x <- matrix(c(6,17,34), nrow = 1)

colnames(new_x) <- c("experience",
                     "education",
                     "age")

ridge_prediction <- predict(
  cv_ridge,
  newx = new_x,
  s = "lambda.min"
)

print("Ridge Predicted Salary")
print(ridge_prediction)


# ==============================================
# PART C: OLS VS RIDGE COMPARISON
# ==============================================

# OLS Model

ols <- lm(salary ~ experience + education + age,
          data = data)

print("OLS Coefficients")
print(coef(ols))


# Ridge Model

ridge <- cv.glmnet(x, y, alpha = 0)

print("Ridge Coefficients")
print(coef(ridge, s = "lambda.min"))


# Compare Predictions

ols_prediction <- predict(
  ols,
  newdata = new_employee
)

ridge_prediction <- predict(
  ridge,
  newx = new_x,
  s = "lambda.min"
)

print("OLS Prediction")
print(ols_prediction)

print("Ridge Prediction")
print(ridge_prediction)


# ==============================================
# PART D: PRACTICE 1 - HOUSE PRICE PREDICTION
# ==============================================

# Step 1: Create House Dataset

area <- c(1000,1200,1400,1600,1800,2000,2200,2400)

bedrooms <- c(2,2,3,3,3,4,4,5)

house_age <- c(10,8,7,6,5,4,3,2)

price <- c(50,60,72,80,90,105,120,135)

house_data <- data.frame(
  area,
  bedrooms,
  house_age,
  price
)

print("House Dataset")
print(house_data)


# Step 2: Multiple Linear Regression

house_model <- lm(
  price ~ area + bedrooms + house_age,
  data = house_data
)


# Step 3: Model Summary

print("House Model Summary")
summary(house_model)


# Step 4: Regression Equation Coefficients

print("House Regression Coefficients")
coef(house_model)


# Step 5: R-squared

print("House R-squared")
summary(house_model)$r.squared


# Step 6: Adjusted R-squared

print("House Adjusted R-squared")
summary(house_model)$adj.r.squared


# Step 7: Significant Predictors

print("Significant Predictors")
summary(house_model)$coefficients


# Step 8: Predict House Price

new_house <- data.frame(
  area = 1500,
  bedrooms = 3,
  house_age = 5
)

house_prediction <- predict(
  house_model,
  newdata = new_house
)

print("Predicted House Price")
print(house_prediction)


# Step 9: Diagnostic Plots

graphics.off()

par(mfrow = c(2,2))
plot(house_model)

par(mfrow = c(1,1))


# ==============================================
# PART E: RIDGE REGRESSION PRACTICE
# ==============================================

# Using the available salary dataset.
# Student marks dataset was not provided.

# Step 1: Predictor Matrix

practice_x <- as.matrix(
  data[, c("experience", "education", "age")]
)


# Step 2: Dependent Variable

practice_y <- data$salary


# Step 3: Ridge Regression

practice_ridge <- glmnet(
  practice_x,
  practice_y,
  alpha = 0
)


# Step 4: Cross Validation

set.seed(123)

practice_cv <- cv.glmnet(
  practice_x,
  practice_y,
  alpha = 0
)


# Step 5: Lambda Minimum

print("Practice Lambda Minimum")
print(practice_cv$lambda.min)


# Step 6: Ridge Coefficients

print("Practice Ridge Coefficients")
coef(practice_cv, s = "lambda.min")


# Step 7: Predict New Employee

practice_new <- matrix(c(6,17,34), nrow = 1)

colnames(practice_new) <- c(
  "experience", "education", "age"
)

practice_prediction <- predict(
  practice_cv,
  newx = practice_new,
  s = "lambda.min"
)

print("Practice Ridge Prediction")
print(practice_prediction)


# ==============================================
# END OF PRACTICAL 6
# ==============================================
