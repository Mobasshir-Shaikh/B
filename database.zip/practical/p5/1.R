x1 <- c(2, 4, 6, 8, 10, 12, 14, 16)
y1 <- c(5, 9, 13, 18, 22, 29, 31, 37)
w1 <- c(1, 1, 2, 2, 3, 3, 4, 4)

data1 <- data.frame(x1, y1, w1)

# OLS Regression
ols1 <- lm(y1 ~ x1, data = data1)

# WLS Regression
wls1 <- lm(y1 ~ x1, data = data1, weights = w1)

# Display results
print("Practice 1: OLS Summary")
summary(ols1)

print("Practice 1: WLS Summary")
summary(wls1)

# Compare coefficients
print("OLS Coefficients")
coef(ols1)

print("WLS Coefficients")
coef(wls1)

# Compare residuals
print("OLS Residuals")
residuals(ols1)

print("WLS Residuals")
residuals(wls1)

# Plot both regression lines
plot(x1, y1,
     main = "Practice 1: OLS vs WLS",
     xlab = "X",
     ylab = "Y",
     pch = 19,
     col = "blue")

abline(ols1, col = "red", lwd = 2)
abline(wls1, col = "green", lwd = 2)

legend("topleft",
       legend = c("OLS", "WLS"),
       col = c("red", "green"),
       lwd = 2)
