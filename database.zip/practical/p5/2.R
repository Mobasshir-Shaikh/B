x <- 1:8
y <- c(3, 5, 7, 9, 11, 13, 15, 17)
w <- c(1, 1, 2, 2, 3, 3, 4, 4)

data <- data.frame(x, y, w)

print("Main Dataset")
print(data)

# Ordinary Least Squares (OLS)
ols_model <- lm(y ~ x, data = data)

print("OLS Model Summary")
summary(ols_model)

# Weighted Least Squares (WLS)
wls_model <- lm(y ~ x, data = data, weights = w)

print("WLS Model Summary")
summary(wls_model)

# Compare coefficients
print("OLS Coefficients")
coef(ols_model)

print("WLS Coefficients")
coef(wls_model)

# Predictions
print("OLS Predictions")
predict(ols_model)

print("WLS Predictions")
predict(wls_model)

# Residual analysis
print("OLS Residuals")
residuals(ols_model)

print("WLS Residuals")
residuals(wls_model)

# Plot data and regression lines
plot(x, y,
     main = "OLS and WLS Regression",
     xlab = "X Values",
     ylab = "Y Values",
     pch = 19,
     col = "blue")

abline(ols_model, col = "red", lwd = 2)
abline(wls_model, col = "green", lwd = 2)

legend("topleft",
       legend = c("OLS Line", "WLS Line"),
       col = c("red", "green"),
       lwd = 2)

# Residual plot
plot(fitted(wls_model), residuals(wls_model),
     main = "WLS Residual Plot",
     xlab = "Fitted Values",
     ylab = "Residuals",
     pch = 19)

abline(h = 0, col = "red", lwd = 2)
