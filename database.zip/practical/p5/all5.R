
# PRACTICAL 5: WEIGHTED LEAST SQUARES USING R

library(stats)

# -----------------------------------
# PART 1: MAIN EXAMPLE
# -----------------------------------

# Create data
x <- 1:8
y <- c(3, 5, 7, 9, 11, 13, 15, 17)
w <- c(1, 1, 2, 2, 3, 3, 4, 4)

data <- data.frame(x, y, w)

print("Main Dataset")
print(data)

# Ordinary Least Squares (OLS)
ols_model <- lm(y ~ x, data = data)

print("OLS Model Summary")
summary(ols_model)

# Weighted Least Squares (WLS)
wls_model <- lm(y ~ x, data = data, weights = w)

print("WLS Model Summary")
summary(wls_model)

# Compare coefficients
print("OLS Coefficients")
coef(ols_model)

print("WLS Coefficients")
coef(wls_model)

# Predictions
print("OLS Predictions")
predict(ols_model)

print("WLS Predictions")
predict(wls_model)

# Residual analysis
print("OLS Residuals")
residuals(ols_model)

print("WLS Residuals")
residuals(wls_model)

# Plot data and regression lines
plot(x, y,
     main = "OLS and WLS Regression",
     xlab = "X Values",
     ylab = "Y Values",
     pch = 19,
     col = "blue")

abline(ols_model, col = "red", lwd = 2)
abline(wls_model, col = "green", lwd = 2)

legend("topleft",
       legend = c("OLS Line", "WLS Line"),
       col = c("red", "green"),
       lwd = 2)

# Residual plot
plot(fitted(wls_model), residuals(wls_model),
     main = "WLS Residual Plot",
     xlab = "Fitted Values",
     ylab = "Residuals",
     pch = 19)

abline(h = 0, col = "red", lwd = 2)


# -----------------------------------
# PART 2: PRACTICE QUESTION 1
# -----------------------------------

x1 <- c(2, 4, 6, 8, 10, 12, 14, 16)
y1 <- c(5, 9, 13, 18, 22, 29, 31, 37)
w1 <- c(1, 1, 2, 2, 3, 3, 4, 4)

data1 <- data.frame(x1, y1, w1)

# OLS Regression
ols1 <- lm(y1 ~ x1, data = data1)

# WLS Regression
wls1 <- lm(y1 ~ x1, data = data1, weights = w1)

# Display results
print("Practice 1: OLS Summary")
summary(ols1)

print("Practice 1: WLS Summary")
summary(wls1)

# Compare coefficients
print("OLS Coefficients")
coef(ols1)

print("WLS Coefficients")
coef(wls1)

# Compare residuals
print("OLS Residuals")
residuals(ols1)

print("WLS Residuals")
residuals(wls1)

# Plot both regression lines
plot(x1, y1,
     main = "Practice 1: OLS vs WLS",
     xlab = "X",
     ylab = "Y",
     pch = 19,
     col = "blue")

abline(ols1, col = "red", lwd = 2)
abline(wls1, col = "green", lwd = 2)

legend("topleft",
       legend = c("OLS", "WLS"),
       col = c("red", "green"),
       lwd = 2)


# -----------------------------------
# PART 3: PRACTICE QUESTION 2
# -----------------------------------

income <- c(20, 30, 40, 50, 60, 70, 80, 90)

expenditure <- c(15, 23, 31, 38, 49, 54, 63, 75)

weight <- c(1, 1, 1, 2, 2, 3, 3, 4)

data2 <- data.frame(income, expenditure, weight)

# Perform WLS Regression
wls2 <- lm(expenditure ~ income,
           data = data2,
           weights = weight)

# Display model summary
print("Practice 2: WLS Summary")
summary(wls2)

# Display coefficients
print("WLS Coefficients")
coef(wls2)

# Fitted values
print("Fitted Values")
fitted(wls2)

# Residuals
print("Residuals")
residuals(wls2)

# Predict expenditure for income = 100
new_data <- data.frame(income = 100)

print("Predicted Expenditure")
predict(wls2, newdata = new_data)

# Plot WLS regression line
plot(income, expenditure,
     main = "Income vs Expenditure (WLS)",
     xlab = "Income",
     ylab = "Expenditure",
     pch = 19,
     col = "blue")

abline(wls2, col = "red", lwd = 2)


# -----------------------------------
# END OF PRACTICAL 5
# -----------------------------------
