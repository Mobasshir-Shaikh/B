income <- c(20, 30, 40, 50, 60, 70, 80, 90)

expenditure <- c(15, 23, 31, 38, 49, 54, 63, 75)

weight <- c(1, 1, 1, 2, 2, 3, 3, 4)

data2 <- data.frame(income, expenditure, weight)

# Perform WLS Regression
wls2 <- lm(expenditure ~ income,
           data = data2,
           weights = weight)

# Display model summary
print("Practice 2: WLS Summary")
summary(wls2)

# Display coefficients
print("WLS Coefficients")
coef(wls2)

# Fitted values
print("Fitted Values")
fitted(wls2)

# Residuals
print("Residuals")
residuals(wls2)

# Predict expenditure for income = 100
new_data <- data.frame(income = 100)

print("Predicted Expenditure")
predict(wls2, newdata = new_data)

# Plot WLS regression line
plot(income, expenditure,
     main = "Income vs Expenditure (WLS)",
     xlab = "Income",
     ylab = "Expenditure",
     pch = 19,
     col = "blue")

abline(wls2, col = "red", lwd = 2)
